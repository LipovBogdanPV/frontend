var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var config_exports = {};
__export(config_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(config_exports);
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
async function handler(event) {
  try {
    const q = event.queryStringParameters || {};
    const envUrl = process.env.SHEETS_WEBAPP_URL || process.env.SHEETS_WEBAPP_URL || "";
    const gasUrl = q.gas && q.gas.trim() || envUrl;
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 204, headers: CORS_HEADERS };
    }
    if (!gasUrl) {
      return {
        statusCode: 500,
        headers: CORS_HEADERS,
        body: JSON.stringify({ success: false, error: "SHEETS_WEBAPP_URL (\u0430\u0431\u043E SHEETS_WEBAPP_URL) \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E" })
      };
    }
    const target = `${gasUrl}?action=config`;
    if (event.httpMethod === "GET") {
      const r = await fetch(target, { method: "GET" });
      const text = await r.text();
      try {
        const json = JSON.parse(text);
        return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(json) };
      } catch {
        return { statusCode: 200, headers: CORS_HEADERS, body: text };
      }
    }
    if (event.httpMethod === "POST") {
      const body = event.body ? JSON.parse(event.body) : {};
      const r = await fetch(target, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const text = await r.text();
      try {
        const json = JSON.parse(text);
        return { statusCode: r.ok ? 200 : 500, headers: CORS_HEADERS, body: JSON.stringify(json) };
      } catch {
        return { statusCode: r.ok ? 200 : 500, headers: CORS_HEADERS, body: text };
      }
    }
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: false, error: "METHOD_NOT_ALLOWED" })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: false, error: String(err) })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
