var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var edit_telegram_exports = {};
__export(edit_telegram_exports, {
  default: () => edit_telegram_default
});
module.exports = __toCommonJS(edit_telegram_exports);
const KV_CACHE_TTL = 12 * 60 * 60 * 1e3;
let KV = null, kvFetchedAt = 0;
const ensureFetch = async () => {
  if (typeof fetch === "function") return fetch;
  const mod = await import("node-fetch");
  return mod.default;
};
async function loadKV(force = false) {
  const base = process.env.SHEETS_WEBAPP_URL || process.env.SHIFTTIME_SHEETS_URL || "";
  if (!base) {
    KV = {};
    return KV;
  }
  const fresh = Date.now() - kvFetchedAt < KV_CACHE_TTL;
  if (!force && KV && fresh) return KV;
  try {
    const f = await ensureFetch();
    const url = `${base.replace(/\/+$/, "")}?mode=kv`;
    const r = await f(url);
    const json = await r.json().catch(() => ({}));
    const items = Array.isArray(json.items) ? json.items : [];
    KV = Object.fromEntries(items.map((it) => [
      String(it.key || "").trim(),
      String((it.value ?? "").toString().trim())
    ]));
    kvFetchedAt = Date.now();
  } catch {
    KV = {};
  }
  return KV;
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }
  try {
    const f = await ensureFetch();
    const p = JSON.parse(event.body || "{}");
    const force = p.forceRefresh === true || p.forceRefresh === "1" || event.queryStringParameters && event.queryStringParameters.force === "1";
    await loadKV(!!force);
    const BOT_TOKEN = (KV.TELEGRAM_BOT_TOKEN || KV.TG_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN || process.env.TG_BOT_TOKEN || "").trim();
    if (!BOT_TOKEN) {
      return { statusCode: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "Telegram bot token is missing" }) };
    }
    const chat_id = (p.chatId || "").toString().trim();
    const messageId = Number(p.messageId);
    const text = (p.text || "").toString().trim();
    const parseMode = (p.parseMode ?? "HTML") || void 0;
    if (!chat_id) return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "chatId is required" }) };
    if (!messageId || Number.isNaN(messageId))
      return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "messageId is required" }) };
    if (!text) return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "text is required" }) };
    const payload = { chat_id, message_id: messageId, text };
    if (parseMode) payload.parse_mode = parseMode;
    const resp = await f(`https://api.telegram.org/bot${BOT_TOKEN}/editMessageText`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await resp.json().catch(async () => ({ ok: false, description: await resp.text() }));
    if (!data.ok) {
      return { statusCode: 502, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: data.description || "Telegram error", telegram: data }) };
    }
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: true }) };
  } catch (e) {
    return { statusCode: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: String(e) }) };
  }
};
var edit_telegram_default = async (req, res) => {
  try {
    const { chatId, messageId, text } = await req.json();
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!chatId || !messageId || !text) {
      return res.json({ success: false, error: "chatId/messageId/text required" }, { status: 400 });
    }
    const payload = { chat_id: chatId, message_id: Number(messageId), text };
    const tg = await fetch(`https://api.telegram.org/bot${token}/editMessageText`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const j = await tg.json();
    if (!j.ok) return res.json({ success: false, error: j.description }, { status: 400 });
    return res.json({ success: true });
  } catch (e) {
    return res.json({ success: false, error: String(e) }, { status: 500 });
  }
};
