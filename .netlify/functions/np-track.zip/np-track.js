var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var np_track_exports = {};
__export(np_track_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(np_track_exports);
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
const GAS_BASE = process.env.SHEETS_WEBAPP_URL || "";
const GAS_SECRET_TOKEN = process.env.GAS_SECRET_TOKEN || "";
const SECRET_NAME_NP = "NP_API_KEY";
let _cachedKey = null;
let _cachedAt = 0;
const KEY_TTL_MS = 10 * 60 * 1e3;
async function getNpKey() {
  if (process.env.NP_API_KEY) return process.env.NP_API_KEY;
  const now = Date.now();
  if (_cachedKey && now - _cachedAt < KEY_TTL_MS) return _cachedKey;
  if (!GAS_BASE) throw new Error("SHEETS_WEBAPP_URL missing");
  if (!GAS_SECRET_TOKEN) throw new Error("GAS_SECRET_TOKEN missing");
  const url = `${GAS_BASE}?mode=secret&name=${encodeURIComponent(SECRET_NAME_NP)}&token=${encodeURIComponent(GAS_SECRET_TOKEN)}`;
  const r = await fetch(url, { method: "GET" });
  const j = await r.json();
  if (!j?.success || !j?.value) {
    throw new Error("NP key not found in Google Sheet");
  }
  _cachedKey = String(j.value);
  _cachedAt = now;
  return _cachedKey;
}
async function handler(event) {
  const CORS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST,OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const gasUrl = process.env.SHEETS_WEBAPP_URL || globalThis.SHEETS_WEBAPP_URL || "<<PUT_YOUR_GAS_URL_HERE>>";
    const payload = {
      mode: "np_track",
      ttn: body.ttn || "",
      orderGroup: body.orderGroup || "",
      phone: body.phone || "",
      clientName: body.clientName || "",
      secret: process.env.SHEETS_SECRET || "super-secret-123"
    };
    const res = await fetch(gasUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    return { statusCode: 200, headers: CORS, body: JSON.stringify(data) };
  } catch (err) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ ok: false, error: String(err) })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
