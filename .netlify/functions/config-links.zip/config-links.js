var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var config_links_exports = {};
__export(config_links_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(config_links_exports);
const handler = async (event) => {
  try {
    const q = event.queryStringParameters || {};
    const base = String(process.env.SHEETS_WEBAPP_URL || q.gas || "").trim();
    if (!base) {
      return json(500, { success: false, error: "SHEETS_WEBAPP_URL is not set" });
    }
    const qs = new URLSearchParams(q);
    qs.delete("gas");
    const target = base + (base.includes("?") ? "&" : "?") + qs.toString();
    if (qs.get("debug") === "1") {
      return json(200, { success: true, debug: { base, target, method: event.httpMethod } });
    }
    const r = await fetch(target, {
      method: event.httpMethod === "POST" ? "POST" : "GET",
      headers: { accept: "application/json" },
      body: event.httpMethod === "POST" ? event.body : void 0
    });
    const text = await r.text();
    return {
      statusCode: r.status,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store"
      },
      body: text
    };
  } catch (e) {
    return json(500, { success: false, error: String(e) });
  }
};
function json(statusCode, body) {
  return {
    statusCode,
    headers: { "content-type": "application/json; charset=utf-8" },
    body: JSON.stringify(body)
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
