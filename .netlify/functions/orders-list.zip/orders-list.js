var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var orders_list_exports = {};
__export(orders_list_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(orders_list_exports);
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
async function handler(event) {
  try {
    if (event.httpMethod === "OPTIONS") {
      return { statusCode: 204, headers: CORS };
    }
    const envUrl = process.env.SHEETS_WEBAPP_URL || "";
    const q = event.queryStringParameters || {};
    const gas = q.gas && q.gas.trim() || envUrl;
    if (!gas) {
      return {
        statusCode: 500,
        headers: CORS,
        body: JSON.stringify({ success: false, error: "SHEETS_WEBAPP_URL \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E" })
      };
    }
    const target = `${gas}${gas.includes("?") ? "&" : "?"}mode=orders`;
    const r = await fetch(target, { method: "GET" });
    const text = await r.text();
    if (!r.ok) {
      return {
        statusCode: r.status,
        headers: CORS,
        body: JSON.stringify({ success: false, error: `GAS HTTP ${r.status}`, head: text.slice(0, 300) })
      };
    }
    if (text.trim().startsWith("<")) {
      return {
        statusCode: 502,
        headers: CORS,
        body: JSON.stringify({ success: false, error: "GAS \u043F\u043E\u0432\u0435\u0440\u043D\u0443\u0432 HTML \u0437\u0430\u043C\u0456\u0441\u0442\u044C JSON", head: text.slice(0, 300) })
      };
    }
    return { statusCode: 200, headers: CORS, body: text };
  } catch (err) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, error: String(err) })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
